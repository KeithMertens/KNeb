class PrintStudent:
    def __init__(self, student):
        self.student_data = student

    def print_student(self, id_number):
        for i in self.student_data.allstudents:
            if i.idnum == id_number:
                print("Student Found")
                print("======Student Information======\n")
                print(i)
                print("\n========Nothing Follows========")
                return
        print(f"The ID number {id_number} does not exist")
        return