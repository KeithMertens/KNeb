class PrintAllStudents:
    def __init__(self, student):
        self.student_data = student

    def print_all_students(self):
        print("===== All Student Information =====\n")
        for i in self.student_data.allstudents:
            print(i)
            print()
        print("========= Nothing Follows =========")