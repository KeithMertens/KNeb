from student import StudentInfo
class AddStudent:
    def __init__(self, student):
        self.student_data = student

    def add_student(self, student):
        self.student_data.allstudents.append(student)
        print(f"Added student {student.getName()} to the list.")

    def input_student(self):
        newStudent = StudentInfo()
        print("=Add new student=")
        name = input("Enter Name: ")
        newStudent.setName(name)
        age = input("Enter Age: ")
        newStudent.setAge(age)
        idnum = input("Enter Student ID: ")
        newStudent.setIDNum(idnum)
        email = input("Enter Email Address: ")
        newStudent.setEmail(email)
        phone_num = input("Enter Phone Number: ")
        newStudent.setPhoneNum(phone_num)
        print("=Nothing Follows=")
        self.add_student(newStudent)