from student import StudentInfo
from add_student import AddStudent
from print_student import PrintStudent
from print_all_student import PrintAllStudents

stu = StudentInfo()
addstudent = AddStudent(stu)
printstudent = PrintStudent(stu)
printall = PrintAllStudents(stu)

user = StudentInfo()
user.setName("Kenjie")
user.setAge("20")
user.setIDNum("2023-2-12345")
user.setEmail("2023-2-12345@lpunetwork.edu.ph")
user.setPhoneNum("09556473846")
addstudent.add_student(user)

def main():
    print("Welcome, Admin Kenjie!")
    print("Please choose from the following options")
    print("1. View your Information")
    print("2. View other student's information")
    print("3. Register a new student")
    print("4. Print all student in list")
    print("5. Exit")
    choice = input("your choice: ")

    if choice == "1":
        printstudent.print_student(user.getIDNum())
        loop = input("Go back to menu? Y/N: ").upper()
        if loop == "Y":
            main()
        elif loop == "N":
            exit()
        else: 
            main()
    elif choice == "2":
        studentNumber = input("Enter student number: ")
        printstudent.print_student(studentNumber)
        loop = input("Go back to menu? Y/N: ").upper()
        if loop == "Y":
            main()
        elif loop == "N":
            exit()
        else: 
            main()
    elif choice == "3":
        addstudent.input_student()
        loop = input("Go back to menu? Y/N: ").upper()
        if loop == "Y":
            main()
        elif loop == "N":
            exit()
        else: 
            main()
    elif choice == "4":
        printall.print_all_students()
        loop = input("Go back to menu? Y/N: ").upper()
        if loop == "Y":
            main()
        elif loop == "N":
            exit()
        else: 
            main()
    elif choice == "5":
        exit()
    else: 
        print("Error 1 to 5 only")
        main()

if __name__ == "__main__": 
    main()